package com.example.tarea_javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        scene.getStylesheets().add(
                HelloApplication.class.getResource("/com/example/tarea_javafx/Estilos.css").toExternalForm()
        );
        stage.setTitle("TAREA:JAVAFX");
        stage.setScene(scene);
        stage.show();
    }
}

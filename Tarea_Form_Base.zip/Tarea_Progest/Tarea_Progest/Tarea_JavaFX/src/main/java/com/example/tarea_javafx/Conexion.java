package com.example.tarea_javafx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static final String URL =
            "jdbc:postgresql://localhost:5432/formulario";
    private static final String user = "postgres";
    private static final String password = "123456";

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, user, password);
    }
}
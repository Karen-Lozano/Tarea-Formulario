module com.example.tarea_javafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.tarea_javafx to javafx.fxml;
    exports com.example.tarea_javafx;
}
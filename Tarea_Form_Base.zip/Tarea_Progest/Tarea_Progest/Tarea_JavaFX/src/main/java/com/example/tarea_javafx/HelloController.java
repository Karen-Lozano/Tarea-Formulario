package com.example.tarea_javafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtPrecio;
    @FXML
    private TextField txtStock;
    @FXML
    private Label lblMensaje;
    @FXML
    private Button btnSalir;
    @FXML
    private TableView<Producto> tblProductos;
    @FXML
    private TableColumn<Producto,Integer> colId;
    @FXML
    private TableColumn<Producto,String> colNombre;
    @FXML
    private TableColumn<Producto,Double> colPrecio;
    @FXML
    private TableColumn<Producto,Integer> colStock;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
    }

    @FXML
    private void guardar(){
        if(txtNombre.getText().isEmpty() ||
           txtPrecio.getText().isEmpty() ||
           txtStock.getText().isEmpty()){
            lblMensaje.setText("Debe completar todos los campos");
            return;
        }

        String sql = "INSERT INTO productos(nombre,precio,stock) Values (?,?,?)";
        try(Connection connection = Conexion.getConexion();
            PreparedStatement ps = connection.prepareStatement(sql)){
            ps.setString(1,txtNombre.getText());
            ps.setDouble(2,Double.parseDouble(txtPrecio.getText()));
            ps.setInt(3,Integer.parseInt(txtStock.getText()));
            ps.executeUpdate();
            lblMensaje.setText("Producto guardado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void mostrar(){
        ObservableList<Producto> lista = FXCollections.observableArrayList();
        String sql = "Select * FROM productos";

        try(Connection connection = Conexion.getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(
                        new Producto(
                                rs.getInt("id"),
                                rs.getString("nombre"),
                                rs.getDouble("precio"),
                                rs.getInt("stock")
                        )
                );
            tblProductos.setItems(lista);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    private void limpiar(){
        txtNombre.clear();
        txtPrecio.clear();
        txtStock.clear();
        lblMensaje.setText("");
    }

    @FXML
    private void salir(){
        Stage stage = (Stage) btnSalir.getScene().getWindow();
        stage.close();
    }
}
